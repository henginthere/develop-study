package com.ssafy.test;

public interface CalculationService {
	
	public int add(int i, int j);
	
}	
