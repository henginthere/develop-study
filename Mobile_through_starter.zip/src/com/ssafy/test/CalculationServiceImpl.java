package com.ssafy.test;

public class CalculationServiceImpl implements CalculationService{
	
	public int add(int i, int j) {
		return i + j;
	}
	
}	
